clear all; clc; close all;

%%%Compute ASD vs TD difference using linear mixed effect model (random slope and random intercept)
%%%Covarites:age, sex and total brain measures (eTIV/total SA/mean thickness)
load Replication_demographMRIfreeSurfer_info;
Subject = cellstr(Replication_demographMRIfreeSurfer.SubjectID);
diagnosis_tmp = cellstr(Replication_demographMRIfreeSurfer.Diagnosis);
ASD_ind = find(strcmp(diagnosis_tmp,'ASD'));
TD_ind = find(strcmp(diagnosis_tmp,'TD'));
ASD_TD_ind = [ASD_ind;TD_ind];
Diagnosis = zeros(size(diagnosis_tmp));
Diagnosis(TD_ind) = 1; %%TD = 1;
Gender_tmp = cellstr(Replication_demographMRIfreeSurfer.Sex);
Gender = zeros(size(Gender_tmp));
Gender(find(strcmp(Gender_tmp,'F'))) = 1; %%female = 1;
Age = Replication_demographMRIfreeSurfer.age;
eTIV = Replication_demographMRIfreeSurfer.eTIV;
tSA = Replication_demographMRIfreeSurfer.totalSA;
meanthickness = Replication_demographMRIfreeSurfer.meanThickness;
freeSurfer_measure_name = Replication_demographMRIfreeSurfer_varName(8:end);
freeSurfer_measure = table2array(Replication_demographMRIfreeSurfer(:,[8:end]));
lme_ASDvsTD_p = NaN(length(freeSurfer_measure_name),1); 
lme_ASDvsTD_beta = NaN(length(freeSurfer_measure_name),1);
lme_ASDvsTD_t = NaN(length(freeSurfer_measure_name),1);
lme_ASDvsTD_DF = NaN(length(freeSurfer_measure_name),1);
lme_ASDvsTD_cohensD = NaN(length(freeSurfer_measure_name),1);
lme_ASDvsTD_cohensD_CI = NaN(length(freeSurfer_measure_name),2);
lme_ASDvsTD_resid_normality_h = NaN(length(freeSurfer_measure_name),1);
lme_ASDvsTD_resid_normality_p = NaN(length(freeSurfer_measure_name),1);
X1_volume = [ones(length(Diagnosis),1),Diagnosis,Gender,Age,eTIV];
X1_SA = [ones(length(Diagnosis),1),Diagnosis,Gender,Age,tSA];
X1_thickness = [ones(length(Diagnosis),1),Diagnosis,Gender,Age,meanthickness];
Z1_randSlope = [ones(length([Diagnosis]),1),Age];
G1 = cell2mat(Subject);
for i = 1:length(freeSurfer_measure_name)
    y1 = freeSurfer_measure(:,i);
    if ~isnan(strfind(freeSurfer_measure_name{i},'volume'))
        lme_tmp = fitlmematrix(X1_volume(ASD_TD_ind,:),y1(ASD_TD_ind),Z1_randSlope(ASD_TD_ind,:),G1(ASD_TD_ind),'FixedEffectPredictors',{'Intercept','Diagnosis','Gender','Age','eTIV'},'RandomEffectPredictors',{{'Intercept','Age'}},'RandomEffectGroups',{'Subject'}); 
        lme_coef = lme_tmp.Coefficients;
        lme_ASDvsTD_fitted = fitted(lme_tmp);
        y1_err = y1(ASD_TD_ind)-lme_ASDvsTD_fitted;
        y1_diagnosis_fittedpluserr = X1_volume(ASD_TD_ind,[1:2])*lme_coef.Estimate([1:2])+y1_err;
    elseif ~isnan(strfind(freeSurfer_measure_name{i},'area'))
        lme_tmp = fitlmematrix(X1_SA(ASD_TD_ind,:),y1(ASD_TD_ind),Z1_randSlope(ASD_TD_ind,:),G1(ASD_TD_ind),'FixedEffectPredictors',{'Intercept','Diagnosis','Gender','Age','tSA'},'RandomEffectPredictors',{{'Intercept','Age'}},'RandomEffectGroups',{'Subject'}); 
        lme_coef = lme_tmp.Coefficients;
        lme_ASDvsTD_fitted = fitted(lme_tmp);
        y1_err = y1(ASD_TD_ind)-lme_ASDvsTD_fitted;
        y1_diagnosis_fittedpluserr = X1_SA(ASD_TD_ind,[1:2])*lme_coef.Estimate([1:2])+y1_err;
    elseif ~isnan(strfind(freeSurfer_measure_name{i},'thickness'))
        lme_tmp = fitlmematrix(X1_thickness(ASD_TD_ind,:),y1(ASD_TD_ind),Z1_randSlope(ASD_TD_ind,:),G1(ASD_TD_ind),'FixedEffectPredictors',{'Intercept','Diagnosis','Gender','Age','meanThickness'},'RandomEffectPredictors',{{'Intercept','Age'}},'RandomEffectGroups',{'Subject'}); 
        lme_coef = lme_tmp.Coefficients;
        lme_ASDvsTD_fitted = fitted(lme_tmp);
        y1_err = y1(ASD_TD_ind)-lme_ASDvsTD_fitted;
        y1_diagnosis_fittedpluserr = X1_thickness(ASD_TD_ind,[1:2])*lme_coef.Estimate([1:2])+y1_err;
    end
    lme_ASDvsTD_p(i) = lme_coef.pValue(2); 
    lme_ASDvsTD_beta(i) = lme_coef.Estimate(2); 
    lme_ASDvsTD_t(i) = lme_coef.tStat(2); 
    lme_ASDvsTD_DF(i) = lme_coef.DF(2); 
    lme_ASDvsTD_cohensD_CI_tmp = meanEffectSize(y1_diagnosis_fittedpluserr(1:length(ASD_ind)), y1_diagnosis_fittedpluserr(length(ASD_ind)+1:end),Effect="cohen",Paired=false,ConfidenceIntervalType="exact");
    lme_ASDvsTD_cohensD(i) = lme_ASDvsTD_cohensD_CI_tmp.Effect; 
    lme_ASDvsTD_cohensD_CI(i,:) = lme_ASDvsTD_cohensD_CI_tmp.ConfidenceIntervals;

    %%%check whether residual forms a standard normal distribution or not
    [lme_ASDvsTD_resid_normality_h(i),lme_ASDvsTD_resid_normality_p(i)] = kstest((y1_err-nanmean(y1_err))/nanstd(y1_err));

    %%boxplot
    figure;boxplot(y1_diagnosis_fittedpluserr/1000,diagnosis_tmp(ASD_TD_ind))
    hold on
    [C, ~, ic]= unique(diagnosis_tmp(ASD_TD_ind),'stable');
    scatter(ic,y1_diagnosis_fittedpluserr/1000,'filled','MarkerFaceAlpha',0.6','jitter','on','jitterAmount',0.15);
    ylabel(freeSurfer_measure_name{i});
    hold off
end

%%%%SVM for language prediction (sMRI+clinic model)
%%%Input variables
%%%1, predictors_train_n; %%%% 125 ASD toddlers (80% samples),contains all MRI and clinic features
%%%2, predictors_test_n;  %%%% 32 ASD toddlers (20% samples),contains all MRI and clinic features
%%%3, Y_mullenlanguage_outcome_group_train;
%%%4, Y_mullenlanguage_outcome_group_test;
%%%%%%%%%%%%%%%%%select the best lambda%%%%%%%%%%%%%%%%%
rng(12345)
%%%training using SVM with ridge (L2) regularization
[CVMdl] = fitclinear(predictors_train_n,Y_mullenlanguage_outcome_group_train,'ObservationsIn','rows','KFold',5,'Lambda',Lambda,'Regularization','ridge','Learner','svm','Verbose',1);
accuracy_lambdaneg4to0 = kfoldLoss(CVMdl);
idxFinal = find(log10(accuracy_lambdaneg4to0)==min(log10(accuracy_lambdaneg4to0)));
opt_lambda = Lambda(idxFinal)

%%%refit using the best lambda trained with ridge (L2) regularization, ASDpoor = 1; ASD good = 0;
Mdl_F = fitclinear(predictors_train_n,Y_mullenlanguage_outcome_group_train,'ObservationsIn','rows','Lambda',opt_lambda,'Learner','svm','Regularization','ridge','Verbose',1);
Y_mullenlanguage_outcome_group_train_log = zeros(size(Y_mullenlanguage_outcome_group_train));
Y_mullenlanguage_outcome_group_train_log(find(strcmp(Y_mullenlanguage_outcome_group_train,'ASDpoor'))) = 1;
weights = Mdl_F.Beta;

%%%apply the trained model to the independent testing set.
mullenlanguage_outcome_group_Hat = predict(Mdl_F,predictors_test_n);

% % % % Treat ASD good as 0 and ASD poor as 1
Y_mullenlanguage_outcome_group_test_label = NaN(size(Y_mullenlanguage_outcome_group_test));
Y_mullenlanguage_outcome_group_test_label(find(strcmp(Y_mullenlanguage_outcome_group_test,'ASDgood')))=0;
Y_mullenlanguage_outcome_group_test_label(find(strcmp(Y_mullenlanguage_outcome_group_test,'ASDpoor')))=1;

Y_mullenlanguage_outcome_group_test_predicted = NaN(size(mullenlanguage_outcome_group_Hat));
Y_mullenlanguage_outcome_group_test_predicted(find(strcmp(mullenlanguage_outcome_group_Hat,'ASDgood')))=0;
Y_mullenlanguage_outcome_group_test_predicted(find(strcmp(mullenlanguage_outcome_group_Hat,'ASDpoor')))=1;

[X_mullenlanguage_outcome_clinicsMRIModel_testset,Y_mullenlanguage_outcome_clinicsMRIModel_testset,T_mullenlanguage_outcome_clinicsMRIModel_testset,AUC_mullenlanguage_outcome_clinicsMRIModel_testset,OPTROCPT_mullenlanguage_outcome_clinicsMRIModel_testset,SUBY_mullenlanguage_outcome_clinicsMRIModel_testset,SUBYNAMES_mullenlanguage_outcome_clinicsMRIModel_testset] = perfcurve(Y_mullenlanguage_outcome_group_test_label,Y_mullenlanguage_outcome_group_test_predicted,1);

clinicsMRIModel_testset_actualYes_ind = find(Y_mullenlanguage_outcome_group_test_label==1);
clinicsMRIModel_testset_actualNo_ind = find(Y_mullenlanguage_outcome_group_test_label==0);
clinicsMRIModel_testset_predictedYes_ind = find(Y_mullenlanguage_outcome_group_test_predicted==1);
clinicsMRIModel_testset_predictedNo_ind = find(Y_mullenlanguage_outcome_group_test_predicted==0);
[length(clinicsMRIModel_testset_actualYes_ind) length(clinicsMRIModel_testset_actualNo_ind)]
[length(clinicsMRIModel_testset_predictedYes_ind) length(clinicsMRIModel_testset_predictedNo_ind)]

clinicsMRIModel_testset_TN = length(intersect(clinicsMRIModel_testset_actualNo_ind,clinicsMRIModel_testset_predictedNo_ind));
clinicsMRIModel_testset_TP = length(intersect(clinicsMRIModel_testset_actualYes_ind,clinicsMRIModel_testset_predictedYes_ind));
clinicsMRIModel_testset_FN = length(intersect(clinicsMRIModel_testset_actualYes_ind,clinicsMRIModel_testset_predictedNo_ind));
clinicsMRIModel_testset_FP = length(intersect(clinicsMRIModel_testset_actualNo_ind,clinicsMRIModel_testset_predictedYes_ind));

clinicsMRIModel_testset_accuracy = (clinicsMRIModel_testset_TP+clinicsMRIModel_testset_TN)/length(Y_mullenlanguage_outcome_group_test_label);
clinicsMRIModel_testset_sensitivity = clinicsMRIModel_testset_TP/length(clinicsMRIModel_testset_actualYes_ind);
clinicsMRIModel_testset_specificity = clinicsMRIModel_testset_TN/length(clinicsMRIModel_testset_actualNo_ind);

clinicsMRIModel_testset_performance = [clinicsMRIModel_testset_accuracy clinicsMRIModel_testset_sensitivity clinicsMRIModel_testset_specificity AUC_mullenlanguage_outcome_clinicsMRIModel_testset]


%%%Brain-behavior association using multiple linear regression model for ASD and TD separately (a behavior variable = volume/SA/cortical thinkness of a subregion + age and sex)
TD_adosAtscan_aparc_lh_vlm_asso_beta = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
TD_adosAtscan_aparc_lh_vlm_asso_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
TD_adosAtscan_aparc_lh_vlm_asso_t = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
TD_adosAtscan_aparc_lh_vlm_asso_dfe = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
TD_adosAtscan_aparc_lh_vlm_agesexcorrcted_r = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
TD_adosAtscan_aparc_lh_vlm_agesexcorrcted_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
ASD_adosAtscan_aparc_lh_vlm_asso_beta = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
ASD_adosAtscan_aparc_lh_vlm_asso_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
ASD_adosAtscan_aparc_lh_vlm_asso_t = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
ASD_adosAtscan_aparc_lh_vlm_asso_dfe = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
ASD_adosAtscan_aparc_lh_vlm_agesexcorrcted_r = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));
ASD_adosAtscan_aparc_lh_vlm_agesexcorrcted_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(ados_domain_score,2));

TD_mullenAtscan_aparc_lh_vlm_asso_beta = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
TD_mullenAtscan_aparc_lh_vlm_asso_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
TD_mullenAtscan_aparc_lh_vlm_asso_t = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
TD_mullenAtscan_aparc_lh_vlm_asso_dfe = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
TD_mullenAtscan_aparc_lh_vlm_agesexcorrcted_r = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
TD_mullenAtscan_aparc_lh_vlm_agesexcorrcted_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
ASD_mullenAtscan_aparc_lh_vlm_asso_beta = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
ASD_mullenAtscan_aparc_lh_vlm_asso_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
ASD_mullenAtscan_aparc_lh_vlm_asso_t = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
ASD_mullenAtscan_aparc_lh_vlm_asso_dfe = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
ASD_mullenAtscan_aparc_lh_vlm_agesexcorrcted_r = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));
ASD_mullenAtscan_aparc_lh_vlm_agesexcorrcted_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(mullen_domain_score,2));

TD_vineAtscan_aparc_lh_vlm_asso_beta = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
TD_vineAtscan_aparc_lh_vlm_asso_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
TD_vineAtscan_aparc_lh_vlm_asso_t = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
TD_vineAtscan_aparc_lh_vlm_asso_dfe = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
TD_vineAtscan_aparc_lh_vlm_agesexcorrcted_r = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
TD_vineAtscan_aparc_lh_vlm_agesexcorrcted_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
ASD_vineAtscan_aparc_lh_vlm_asso_beta = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
ASD_vineAtscan_aparc_lh_vlm_asso_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
ASD_vineAtscan_aparc_lh_vlm_asso_t = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
ASD_vineAtscan_aparc_lh_vlm_asso_dfe = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
ASD_vineAtscan_aparc_lh_vlm_agesexcorrcted_r = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));
ASD_vineAtscan_aparc_lh_vlm_agesexcorrcted_p = NaN(size(aparc_lh_volume_matchQCed_1stvst_value,2),size(vine_domain_score,2));

for i = 1:size(aparc_lh_volume_matchQCed_1stvst_value,2)
    aparc_lh_vlm_matchQCed_1stvst_TD_value_t = aparc_lh_volume_matchQCed_1stvst_value(TD_ind,i);
    aparc_lh_vlm_matchQCed_1stvst_ASD_value_t = aparc_lh_volume_matchQCed_1stvst_value(ASD_ind,i);
    subs_aparc_lh_vlm_xtab_name_tmp = subs_aparc_lh_volume_colname{i+1};
    subs_aparc_lh_vlm_xtab_name = strrep(subs_aparc_lh_vlm_xtab_name_tmp,'_','-');
    subs_aparc_lh_vlm_xtab_name = [subs_aparc_lh_vlm_xtab_name,'(cm^3)'];
    for j1 = 1:size(ados_domain_score,2)
        ados_domain_TD_score_tmp = ados_domain_score(TD_ind,j1);
        adosAtscan_aparc_lh_vlm_asso_stats = regstats(ados_domain_TD_score_tmp,[aparc_lh_vlm_matchQCed_1stvst_TD_value_t,Gender_TD,ados_EvaAge(TD_ind)],'linear');
        TD_adosAtscan_aparc_lh_vlm_asso_beta(i,j1) = adosAtscan_aparc_lh_vlm_asso_stats.tstat.beta(2);
        TD_adosAtscan_aparc_lh_vlm_asso_p(i,j1) = adosAtscan_aparc_lh_vlm_asso_stats.tstat.pval(2);
        TD_adosAtscan_aparc_lh_vlm_asso_t(i,j1) = adosAtscan_aparc_lh_vlm_asso_stats.tstat.t(2);
        TD_adosAtscan_aparc_lh_vlm_asso_dfe(i,j1)  = adosAtscan_aparc_lh_vlm_asso_stats.tstat.dfe;
        TD_ADOS_value_agesex_corrcted = ados_domain_TD_score_tmp - ([Gender_TD,ados_EvaAge(TD_ind)])*(adosAtscan_aparc_lh_vlm_asso_stats.tstat.beta([3,4]));
        TD_ADOS_value_sMRI_fitted_tmp = [ones(length(TD_ind),1),aparc_lh_vlm_matchQCed_1stvst_TD_value_t]*(adosAtscan_aparc_lh_vlm_asso_stats.tstat.beta([1,2]));
        [TD_adosAtscan_aparc_lh_vlm_agesexcorrcted_r(i,j1),TD_adosAtscan_aparc_lh_vlm_agesexcorrcted_p(i,j1)] = corr(TD_adosAtscan_aparc_lh_vlm_asso_beta(i,j1)*aparc_lh_vlm_matchQCed_1stvst_TD_value_t,ados_domain_TD_score_tmp,'rows','complete');

        ados_domain_ASD_score_tmp = ados_domain_score(ASD_ind,j1);
        adosAtscan_aparc_lh_vlm_asso_stats = regstats(ados_domain_ASD_score_tmp,[aparc_lh_vlm_matchQCed_1stvst_ASD_value_t,Gender_ASD,ados_EvaAge(ASD_ind)],'linear');
        ASD_adosAtscan_aparc_lh_vlm_asso_beta(i,j1) = adosAtscan_aparc_lh_vlm_asso_stats.tstat.beta(2);
        ASD_adosAtscan_aparc_lh_vlm_asso_p(i,j1) = adosAtscan_aparc_lh_vlm_asso_stats.tstat.pval(2);
        ASD_adosAtscan_aparc_lh_vlm_asso_t(i,j1) = adosAtscan_aparc_lh_vlm_asso_stats.tstat.t(2);
        ASD_adosAtscan_aparc_lh_vlm_asso_dfe(i,j1)  = adosAtscan_aparc_lh_vlm_asso_stats.tstat.dfe;
        ASD_ADOS_value_agesex_corrcted = ados_domain_ASD_score_tmp - ([Gender_ASD,ados_EvaAge(ASD_ind)])*(adosAtscan_aparc_lh_vlm_asso_stats.tstat.beta([3,4]));
        ASD_ADOS_value_sMRI_fitted_tmp = [ones(length(ASD_ind),1),aparc_lh_vlm_matchQCed_1stvst_ASD_value_t]*(adosAtscan_aparc_lh_vlm_asso_stats.tstat.beta([1,2]));
        [ASD_adosAtscan_aparc_lh_vlm_agesexcorrcted_r(i,j1),ASD_adosAtscan_aparc_lh_vlm_agesexcorrcted_p(i,j1)] = corr(ASD_adosAtscan_aparc_lh_vlm_asso_beta(i,j1)*aparc_lh_vlm_matchQCed_1stvst_ASD_value_t,ados_domain_ASD_score_tmp,'rows','complete');
       
        %%%plot sMRI-ADOS fitting
        figure;  
        plot(aparc_lh_vlm_matchQCed_1stvst_value_t(ASD_ind)/1000,ASD_ADOS_value_agesex_corrcted,'.','Color', ASD_color,'markersize',14); 
        hold on; plot(aparc_lh_vlm_matchQCed_1stvst_value_t(TD_ind)/1000,TD_ADOS_value_agesex_corrcted,'.','Color', TD_color,'markersize',14); 
        hold on; plot(aparc_lh_vlm_matchQCed_1stvst_value_t(ASD_ind)/1000, ASD_ADOS_value_sMRI_fitted_tmp, 'Color', ASD_color, 'LineWidth', 2);grid on; 
        hold on; plot(aparc_lh_vlm_matchQCed_1stvst_value_t(TD_ind)/1000, TD_ADOS_value_sMRI_fitted_tmp, 'Color', TD_color, 'LineWidth', 2);grid on; 

        set(gca,'FontSize',14,'fontweight','bold');
        legend('ASD','TD','location', 'Best','fontweight','bold','FontSize',13);
        ados_ytab_name = strrep(ados_domain_name{j1},'_','-');
        ylabel(ados_ytab_name,'fontweight','bold','FontSize', 14);
        xlabel(subs_aparc_lh_vlm_xtab_name,'fontweight','bold','FontSize',14);
        hold off
    end
    for j2 = 1:size(mullen_domain_score,2)
        mullen_domain_TD_score_tmp = mullen_domain_score(TD_ind,j2);
        mullenAtscan_aparc_lh_vlm_asso_stats = regstats(mullen_domain_TD_score_tmp,[aparc_lh_vlm_matchQCed_1stvst_TD_value_t,Gender_TD,mullen_EvaAge(TD_ind)],'linear');
        TD_mullenAtscan_aparc_lh_vlm_asso_beta(i,j2) = mullenAtscan_aparc_lh_vlm_asso_stats.tstat.beta(2);
        TD_mullenAtscan_aparc_lh_vlm_asso_p(i,j2) = mullenAtscan_aparc_lh_vlm_asso_stats.tstat.pval(2);
        TD_mullenAtscan_aparc_lh_vlm_asso_t(i,j2) = mullenAtscan_aparc_lh_vlm_asso_stats.tstat.t(2);
        TD_mullenAtscan_aparc_lh_vlm_asso_dfe(i,j2)  = mullenAtscan_aparc_lh_vlm_asso_stats.tstat.dfe;
        
        TD_mullen_value_agesex_corrcted = mullen_domain_TD_score_tmp - ([Gender_TD,mullen_EvaAge(TD_ind)])*(mullenAtscan_aparc_lh_vlm_asso_stats.tstat.beta([3,4]));
        TD_mullen_value_sMRI_fitted_tmp = [ones(length(TD_ind),1),aparc_lh_vlm_matchQCed_1stvst_TD_value_t]*(mullenAtscan_aparc_lh_vlm_asso_stats.tstat.beta([1,2]));
        [TD_mullenAtscan_aparc_lh_vlm_agesexcorrcted_r(i,j2),TD_mullenAtscan_aparc_lh_vlm_agesexcorrcted_p(i,j2)] = corr(TD_mullenAtscan_aparc_lh_vlm_asso_beta(i,j2)*aparc_lh_vlm_matchQCed_1stvst_TD_value_t,mullen_domain_TD_score_tmp,'rows','complete');

        mullen_domain_ASD_score_tmp = mullen_domain_score(ASD_ind,j2);
        mullenAtscan_aparc_lh_vlm_asso_stats = regstats(mullen_domain_ASD_score_tmp,[aparc_lh_vlm_matchQCed_1stvst_ASD_value_t,Gender_ASD,mullen_EvaAge(ASD_ind)],'linear');
        ASD_mullenAtscan_aparc_lh_vlm_asso_beta(i,j2) = mullenAtscan_aparc_lh_vlm_asso_stats.tstat.beta(2);
        ASD_mullenAtscan_aparc_lh_vlm_asso_p(i,j2) = mullenAtscan_aparc_lh_vlm_asso_stats.tstat.pval(2);
        ASD_mullenAtscan_aparc_lh_vlm_asso_t(i,j2) = mullenAtscan_aparc_lh_vlm_asso_stats.tstat.t(2);
        ASD_mullenAtscan_aparc_lh_vlm_asso_dfe(i,j2)  = mullenAtscan_aparc_lh_vlm_asso_stats.tstat.dfe;
        
        ASD_mullen_value_agesex_corrcted = mullen_domain_ASD_score_tmp - ([Gender_ASD,mullen_EvaAge(ASD_ind)])*(mullenAtscan_aparc_lh_vlm_asso_stats.tstat.beta([3,4]));
        ASD_mullen_value_sMRI_fitted_tmp = [ones(length(ASD_ind),1),aparc_lh_vlm_matchQCed_1stvst_ASD_value_t]*(mullenAtscan_aparc_lh_vlm_asso_stats.tstat.beta([1,2]));
        [ASD_mullenAtscan_aparc_lh_vlm_agesexcorrcted_r(i,j2),ASD_mullenAtscan_aparc_lh_vlm_agesexcorrcted_p(i,j2)] = corr(ASD_mullenAtscan_aparc_lh_vlm_asso_beta(i,j2)*aparc_lh_vlm_matchQCed_1stvst_ASD_value_t,mullen_domain_ASD_score_tmp,'rows','complete');
                
        %%%plot sMRI-mullen fitting 
        figure; 
        plot(aparc_lh_vlm_matchQCed_1stvst_value_t(ASD_ind)/1000,ASD_mullen_value_agesex_corrcted,'.','Color', ASD_color,'markersize',14); 
        hold on; plot(aparc_lh_vlm_matchQCed_1stvst_value_t(TD_ind)/1000,TD_mullen_value_agesex_corrcted,'.','Color', TD_color,'markersize',14);  
        hold on; plot(aparc_lh_vlm_matchQCed_1stvst_value_t(ASD_ind)/1000, ASD_mullen_value_sMRI_fitted_tmp, 'Color', ASD_color, 'LineWidth', 2);grid on;
        hold on; plot(aparc_lh_vlm_matchQCed_1stvst_value_t(TD_ind)/1000, TD_mullen_value_sMRI_fitted_tmp, 'Color', TD_color, 'LineWidth', 2);grid on;

        set(gca,'FontSize',14,'fontweight','bold');
        legend('ASD','TD','location', 'Best','fontweight','bold','FontSize',13);
        mullen_ytab_name = strrep(mullen_domain_name{j2},'_','-');
        ylabel(mullen_ytab_name,'fontweight','bold','FontSize', 14);
        xlabel(subs_aparc_lh_vlm_xtab_name,'fontweight','bold','FontSize',14);
        hold off
    end
    for j3 = 1:size(vine_domain_score,2)
        vine_domain_TD_score_tmp = vine_domain_score(TD_ind,j3);
        vineAtscan_aparc_lh_vlm_asso_stats = regstats(vine_domain_TD_score_tmp,[aparc_lh_vlm_matchQCed_1stvst_TD_value_t,Gender_TD,vine_EvaAge(TD_ind)],'linear');
        TD_vineAtscan_aparc_lh_vlm_asso_beta(i,j3) = vineAtscan_aparc_lh_vlm_asso_stats.tstat.beta(2);
        TD_vineAtscan_aparc_lh_vlm_asso_p(i,j3) = vineAtscan_aparc_lh_vlm_asso_stats.tstat.pval(2);
        TD_vineAtscan_aparc_lh_vlm_asso_t(i,j3) = vineAtscan_aparc_lh_vlm_asso_stats.tstat.t(2);
        TD_vineAtscan_aparc_lh_vlm_asso_dfe(i,j3)  = vineAtscan_aparc_lh_vlm_asso_stats.tstat.dfe;
        
        TD_vine_value_agesex_corrcted = vine_domain_TD_score_tmp - ([Gender_TD,vine_EvaAge(TD_ind)])*(vineAtscan_aparc_lh_vlm_asso_stats.tstat.beta([3,4]));
        TD_vine_value_sMRI_fitted_tmp = [ones(length(TD_ind),1),aparc_lh_vlm_matchQCed_1stvst_TD_value_t]*(vineAtscan_aparc_lh_vlm_asso_stats.tstat.beta([1,2]));
        [TD_vineAtscan_aparc_lh_vlm_agesexcorrcted_r(i,j3),TD_vineAtscan_aparc_lh_vlm_agesexcorrcted_p(i,j3)] = corr(TD_vineAtscan_aparc_lh_vlm_asso_beta(i,j3)*aparc_lh_vlm_matchQCed_1stvst_TD_value_t,vine_domain_TD_score_tmp,'rows','complete');

        vine_domain_ASD_score_tmp = vine_domain_score(ASD_ind,j3);
        vineAtscan_aparc_lh_vlm_asso_stats = regstats(vine_domain_ASD_score_tmp,[aparc_lh_vlm_matchQCed_1stvst_ASD_value_t,Gender_ASD,vine_EvaAge(ASD_ind)],'linear');
        ASD_vineAtscan_aparc_lh_vlm_asso_beta(i,j3) = vineAtscan_aparc_lh_vlm_asso_stats.tstat.beta(2);
        ASD_vineAtscan_aparc_lh_vlm_asso_p(i,j3) = vineAtscan_aparc_lh_vlm_asso_stats.tstat.pval(2);
        ASD_vineAtscan_aparc_lh_vlm_asso_t(i,j3) = vineAtscan_aparc_lh_vlm_asso_stats.tstat.t(2);
        ASD_vineAtscan_aparc_lh_vlm_asso_dfe(i,j3)  = vineAtscan_aparc_lh_vlm_asso_stats.tstat.dfe;
        
        ASD_vine_value_agesex_corrcted = vine_domain_ASD_score_tmp - ([Gender_ASD,vine_EvaAge(ASD_ind)])*(vineAtscan_aparc_lh_vlm_asso_stats.tstat.beta([3,4]));
        ASD_vine_value_sMRI_fitted_tmp = [ones(length(ASD_ind),1),aparc_lh_vlm_matchQCed_1stvst_ASD_value_t]*(vineAtscan_aparc_lh_vlm_asso_stats.tstat.beta([1,2]));
        [ASD_vineAtscan_aparc_lh_vlm_agesexcorrcted_r(i,j3),ASD_vineAtscan_aparc_lh_vlm_agesexcorrcted_p(i,j3)] = corr( ASD_vineAtscan_aparc_lh_vlm_asso_beta(i,j3)*aparc_lh_vlm_matchQCed_1stvst_ASD_value_t,vine_domain_ASD_score_tmp,'rows','complete');
    
        %%%plot sMRI-vine fitting 
        figure; 
        plot(aparc_lh_vlm_matchQCed_1stvst_value_t(ASD_ind)/1000,ASD_vine_value_agesex_corrcted,'.','Color', ASD_color,'markersize',14); 
        hold on; plot(aparc_lh_vlm_matchQCed_1stvst_value_t(TD_ind)/1000,TD_vine_value_agesex_corrcted,'.','Color', TD_color,'markersize',14); 
        hold on; plot(aparc_lh_vlm_matchQCed_1stvst_value_t(ASD_ind)/1000, ASD_vine_value_sMRI_fitted_tmp, 'Color', ASD_color, 'LineWidth', 2);grid on; 
        hold on; plot(aparc_lh_vlm_matchQCed_1stvst_value_t(TD_ind)/1000, TD_vine_value_sMRI_fitted_tmp, 'Color', TD_color, 'LineWidth', 2);grid on; 

        set(gca,'FontSize',14,'fontweight','bold');
        legend('ASD','TD','location', 'Best','fontweight','bold','FontSize',13);
        vine_ytab_name = strrep(vine_domain_name{j3},'_','-');
        ylabel(vine_ytab_name,'fontweight','bold','FontSize', 14);
        xlabel(subs_aparc_lh_vlm_xtab_name,'fontweight','bold','FontSize',14);
        hold off
    end
end
